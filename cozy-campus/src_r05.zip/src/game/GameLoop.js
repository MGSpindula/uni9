export class GameLoop {
    constructor({ game, config, measurePerformance = false }) {
        if (!game) {
            throw new TypeError("GameLoop requires a Game.")
        }

        this.game = game
        this.config = config

        this.measurePerformance = Boolean(measurePerformance)

        this.running = false
        this.animationFrameId = null
        this.previousTime = 0

        this.context = {
            game,
            world: null,
            services: game.services,
            camera: game.renderPipeline.camera,
            delta: 0,
        }

        this.metrics = {
            delta: 0,
            update: 0,
            render: 0,
            rendered: false,

            phases: {
                input: 0,
                controllers: 0,
                navigation: 0,
                entities: 0,
            },
        }

        this.frame = this.frame.bind(this)

        this.handleVisibilityChange = this.handleVisibilityChange.bind(this)

        document.addEventListener(
            "visibilitychange",
            this.handleVisibilityChange,
        )
    }

    start() {
        if (this.running) {
            return
        }

        this.running = true
        this.previousTime = performance.now()

        this.animationFrameId = requestAnimationFrame(this.frame)
    }

    stop() {
        if (!this.running) {
            return
        }

        this.running = false

        if (this.animationFrameId !== null) {
            cancelAnimationFrame(this.animationFrameId)

            this.animationFrameId = null
        }
    }

    frame(now) {
        if (!this.running) {
            return
        }

        if (this.config.pauseWhenHidden && document.hidden) {
            this.previousTime = now

            this.animationFrameId = requestAnimationFrame(this.frame)

            return
        }

        const elapsed = Math.max(0, (now - this.previousTime) / 1000)

        const delta = Math.min(elapsed, this.config.maxDelta)

        this.previousTime = now

        let updateStarted = 0

        if (this.measurePerformance) {
            updateStarted = performance.now()
        }

        this.update(delta)

        if (this.measurePerformance) {
            this.metrics.update = performance.now() - updateStarted
        }

        const shouldRender =
            this.game.renderRequested || this.game.hasContinuousVisualActivity()

        if (shouldRender) {
            let renderStarted = 0

            if (this.measurePerformance) {
                renderStarted = performance.now()
            }

            this.game.render(delta)

            if (this.measurePerformance) {
                this.metrics.render = performance.now() - renderStarted
            }
        } else if (this.measurePerformance) {
            this.metrics.render = 0
        }

        this.metrics.delta = delta
        this.metrics.rendered = shouldRender

        this.animationFrameId = requestAnimationFrame(this.frame)
    }

    update(delta) {
        const game = this.game
        const world = game.world

        if (!world) {
            return
        }

        const services = game.services

        const renderPipeline = game.renderPipeline

        this.context.world = world
        this.context.delta = delta

        let phaseStarted = 0

        if (this.measurePerformance) {
            phaseStarted = performance.now()
        }

        services.selection.update()

        if (renderPipeline.update(delta)) {
            game.requestRender()
        }

        this.finishPhase("input", phaseStarted)

        if (this.measurePerformance) {
            phaseStarted = performance.now()
        }

        world.updateControllers(delta, this.context)

        this.finishPhase("controllers", phaseStarted)

        if (this.measurePerformance) {
            phaseStarted = performance.now()
        }

        services.update(delta)

        this.finishPhase("navigation", phaseStarted)

        if (this.measurePerformance) {
            phaseStarted = performance.now()
        }

        world.updateEntities(delta, this.context)

        this.finishPhase("entities", phaseStarted)

        if (world.requiresContinuousRender()) {
            game.requestRender()
        }
    }

    finishPhase(name, started) {
        if (!this.measurePerformance) {
            return
        }

        this.metrics.phases[name] = performance.now() - started
    }

    handleVisibilityChange() {
        this.previousTime = performance.now()

        if (!document.hidden) {
            this.game.requestRender()
        }
    }

    dispose() {
        this.stop()

        document.removeEventListener(
            "visibilitychange",
            this.handleVisibilityChange,
        )
    }
}
