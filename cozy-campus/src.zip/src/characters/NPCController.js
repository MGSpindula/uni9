import { EntityState } from "../core/EntityState";

export class NPCController {

    constructor({
        npc,
        graph,
        navigationSystem,
        interactionBehavior
    }) {

        this.npc = npc;
        this.graph = graph;
        this.navigationSystem =
            navigationSystem;

        this.interactionBehavior =
            interactionBehavior;

        this.state = "idle";
        this.elapsed = 0;

        this.idleDuration = 1.5;
        this.interactionDuration = 5;

        this.interactionRetryDuration = 5;
        this.interactionRetryRemaining = 0;

        this.unavailableTopologyRevision = null;

    }

    // -----------------------------
    // Internal decision source
    // -----------------------------

    update(delta) {

        this.updateTopologyRetry();

        this.interactionRetryRemaining =
            Math.max(
                0,
                this.interactionRetryRemaining -
                delta
            );

        if (
            this.interactionBehavior
                .isActive(this.npc)
        ) {

            this.updateActiveInteraction(
                delta
            );

            return;

        }

        if (
            this.npc.isState(
                EntityState.WALKING
            ) ||
            this.npc.isState(
                EntityState.WAITING
            ) ||
            this.npc.isState(
                EntityState.STOPPING
            )
        ) {

            return;

        }

        if (
            this.state ===
            "moving-to-interaction"
        ) {

            this.handleAbandonedInteraction();
            return;

        }

        this.elapsed += delta;

        if (
            this.elapsed <
            this.idleDuration
        ) {

            return;

        }

        this.elapsed = 0;

        if (
            this.mayRetryInteraction() &&
            this.tryUseInteraction()
        ) {

            return;

        }

        this.moveToRandomNode();

    }

    // -----------------------------
    // Interaction behavior
    // -----------------------------

    updateTopologyRetry() {

        if (
            this.unavailableTopologyRevision ===
            null
        ) {

            return;

        }

        if (
            this.unavailableTopologyRevision ===
            this.graph.revision
        ) {

            return;

        }

        this.unavailableTopologyRevision =
            null;

        this.interactionRetryRemaining = 0;

    }

    updateActiveInteraction(delta) {

        this.state = "interacting";
        this.elapsed += delta;

        if (
            this.elapsed <
            this.interactionDuration
        ) {

            return;

        }

        this.elapsed = 0;

        // CharacterNavigationSystem sees the active interaction
        // and performs its normal exit before following the new route.
        this.moveToRandomNode();

    }

    mayRetryInteraction() {

        return (
            this.unavailableTopologyRevision ===
            null
        ) &&
        this.interactionRetryRemaining <= 0;

    }

    tryUseInteraction() {

        const accepted =
            this.interactionBehavior
                .tryStart(this.npc);

        if (accepted) {

            this.state =
                "moving-to-interaction";

            this.unavailableTopologyRevision =
                null;

            return true;

        }

        this.postponeInteraction();

        return false;

    }

    postponeInteraction() {

        this.interactionRetryRemaining =
            this.interactionRetryDuration;

        this.unavailableTopologyRevision =
            this.graph.revision;

        console.log(
            `[NPC] ${this.npc.name} postpones ` +
            `its interaction until navigation ` +
            `topology changes.`
        );

    }

    handleAbandonedInteraction() {

        this.state = "idle";
        this.elapsed = 0;

        this.interactionRetryRemaining =
            this.interactionRetryDuration;

        this.unavailableTopologyRevision =
            this.graph.revision;

        console.log(
            `[NPC] ${this.npc.name} abandons ` +
            `its interaction until navigation ` +
            `topology changes.`
        );

        this.moveToRandomNode();

    }

    // -----------------------------
    // Roaming
    // -----------------------------

    moveToRandomNode() {

        const currentNodeId =
            this.npc.navigation
                .getTraversalState()
                .currentNodeId;

        const candidates = [
            ...this.graph.nodes.values()
        ].filter(node =>
            node.id !== currentNodeId &&
            !node.blocked &&
            this.graph.isNodeAvailable(
                node.id,
                this.npc
            )
        );

        if (candidates.length === 0) {

            this.state = "idle";
            return false;

        }

        const node =
            candidates[
                Math.floor(
                    Math.random() *
                    candidates.length
                )
            ];

        const accepted =
            this.navigationSystem
                .moveToClosestNode(
                    this.npc,
                    node.position
                );

        this.state =
            accepted
                ? "roaming"
                : "idle";

        return accepted;

    }

}