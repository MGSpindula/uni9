import * as THREE from "three";

import { Entity } from "../core/Entity";
import { InteractionPoint } from "../navigation/InteractionPoint";
import {
    InteractionDefinition
} from "../core/interactions/InteractionDefinition";

export class CozyCampusInteractionPoints
    extends Entity {

    constructor() {

        super(
            "Cozy Campus Action Points",
            new THREE.Group()
        );

        this.createPoints();
        this.createDefinitions();

        this.disableInteraction();
        this.disableOutline();

    }

    createPoints() {

        this.windowPoint =
            this.addInteractionPoint(
                new InteractionPoint(
                    "ambient:window",
                    {
                        position:
                            new THREE.Vector3(
                                -1.5,
                                0,
                                0
                            ),

                        rotationY:
                            Math.PI * 1.45,

                        connectTo:
                            "junction",

                        terminal:
                            true,

                        metadata: {
                            pose: "lean",
                            role: "action"
                        }
                    }
                )
            );

        this.westPoint =
            this.addInteractionPoint(
                new InteractionPoint(
                    "ambient:west",
                    {
                        position:
                            new THREE.Vector3(
                                4.2,
                                0,
                                8.3
                            ),

                        rotationY:
                            Math.PI * 0.2,

                        connectTo:
                            "west-1",

                        terminal:
                            true,

                        metadata: {
                            pose: "stand",
                            role: "action"
                        }
                    }
                )
            );

        this.eastPoint =
            this.addInteractionPoint(
                new InteractionPoint(
                    "ambient:east",
                    {
                        position:
                            new THREE.Vector3(
                                8.3,
                                0,
                                7
                            ),

                        connectTo:
                            "east-exit",

                        terminal:
                            true,

                        metadata: {
                            pose: "stand",
                            role: "action"
                        }
                    }
                )
            );

        this.spawnPoint =
            this.addInteractionPoint(
                new InteractionPoint(
                    "ambient:spawn",
                    {
                        position:
                            new THREE.Vector3(
                                1.2,
                                0,
                                -9.1
                            ),

                        rotationY:
                            Math.PI * 0.75,

                        connectTo:
                            "spawn",

                        terminal:
                            true,

                        metadata: {
                            pose: "stand",
                            role: "action"
                        }
                    }
                )
            );

    }

    createDefinitions() {

        for (
            const point of
            this.InteractionPoints
        ) {

            this.addInteractionDefinition(
                new InteractionDefinition({
                    id:
                        `idle:${point.id}`,

                    tags: [
                        "npc-action",
                        "idle",
                        "ambient",
                        point.metadata.pose ??
                        "stand"
                    ],

                    point,

                    available: ({
                        actor
                    }) =>
                        point.isAvailable(actor),

                    execute: () => true
                })
            );

        }

    }

}