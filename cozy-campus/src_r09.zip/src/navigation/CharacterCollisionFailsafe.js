import * as THREE from "three";

// Predictive right-of-way guard. It decides who should slow down before
// contact; Cannon remains responsible only for residual physical separation.
export class CharacterCollisionFailsafe {

    constructor(owner, {
        detectionRadius = 1.8,
        predictionTime = 0.34,
        safetyPadding = 0.06,

        /*
         * Dois atores próximos deste raio em relação
         * ao mesmo nó negociam passagem pela fila.
         * Eles não executam sidestep.
         */
        nodeConflictRadius = 1.1,
        nodeConflictReleaseMargin = 0.25,
        nodeConflictHoldDuration = 0.35,

        /*
         * O sidestep é uma micro-manobra. Ele nunca
         * pode continuar indefinidamente.
         */
        sidestepTimeout = 0.9,

        /*
         * Depois que um par conclui ou abandona uma
         * manobra, ele não pode iniciar outra
         * imediatamente.
         */
        sidestepCooldown = 0.7,

        sidestepArrivalDistance = 0.06,

        /*
         * O Player também desvia, porém menos.
         */
        playerSidestepDistance = 0.28,

        /*
         * NPC que deve ceder abre um pouco mais
         * de espaço.
         */
        yieldingSidestepDistance = 0.38,

        /*
         * Mesmo o ator prioritário participa do
         * movimento, ainda que discretamente.
         */
        prioritySidestepDistance = 0.3,

        /*
         * Duas tentativas fracassadas em três
         * segundos provocam replanejamento.
         */
        sidestepFailureWindow = 3,
        maxSidestepFailures = 2
    } = {}) {

        this.owner =
            owner;

        this.detectionRadius =
            detectionRadius;

        this.predictionTime =
            predictionTime;

        this.safetyPadding =
            safetyPadding;

        this.nodeConflictRadius =
            nodeConflictRadius;

        this.nodeConflictReleaseMargin =
            nodeConflictReleaseMargin;

        this.nodeConflictHoldDuration =
            nodeConflictHoldDuration;

        this.sidestepTimeout =
            sidestepTimeout;

        this.sidestepCooldown =
            sidestepCooldown;

        this.sidestepArrivalDistance =
            sidestepArrivalDistance;

        this.playerSidestepDistance =
            playerSidestepDistance;

        this.yieldingSidestepDistance =
            yieldingSidestepDistance;

        this.prioritySidestepDistance =
            prioritySidestepDistance;

        this.sidestepFailureWindow =
            sidestepFailureWindow;

        this.maxSidestepFailures =
            maxSidestepFailures;

        this.waitingFor =
            new Map();

        /*
         * actor → {
         *     other,
         *     target,
         *     side,
         *     elapsed
         * }
         */
        this.sidesteps =
            new Map();

        /*
         * actor → Map<other, expiresAt>
         */
        this.pairCooldowns =
            new Map();

        /*
        * Mantém a classificação de conflito de nó
        * estável por alguns frames.
        *
        * actor → Map<other, {
        *     nodeId,
        *     expiresAt
        * }>
        */
        this.nodeConflictMemory =
            new Map();
        /*
         * actor → number[]
         *
         * Cada número é o instante de um timeout.
         */
        this.sidestepFailures =
            new Map();

        this.velocity =
            new THREE.Vector3();

        this.otherVelocity =
            new THREE.Vector3();

        this.relativePosition =
            new THREE.Vector3();

        this.relativeVelocity =
            new THREE.Vector3();

    }

    canMove(
        actor,
        target,
        delta = 0
    ) {

        this.getIntendedVelocity(
            actor,
            target,
            this.velocity
        );

        /*
         * Esperas nos endpoints são controladas
         * pelo NavigationTrafficSystem.
         *
         * Um sidestep não pode contornar uma fila
         * de chegada ou saída.
         */
        if (
            this.isWaitingAtLaneEndpoint(
                actor
            )
        ) {

            this.sidesteps.delete(
                actor
            );

            return false;

        }

        /*
         * Antes de continuar um sidestep ativo,
         * verifica novamente se o encontro foi
         * reclassificado como conflito de nó.
         *
         * O nome activeNodeConflictId é diferente
         * do nodeConflictId usado mais abaixo para
         * evitar declarações duplicadas.
         */
        const currentSidestep =
            this.sidesteps.get(
                actor
            );

        if (currentSidestep) {

            const activeNodeConflictId =
                this.getNodeConflictId(
                    actor,
                    currentSidestep.other
                );

            if (activeNodeConflictId) {

                this.cancelPairSidestepsForNode(
                    actor,
                    currentSidestep.other,
                    activeNodeConflictId
                );

                const mayProceed =
                    this.resolveNodeConflict(
                        actor,
                        currentSidestep.other,
                        activeNodeConflictId
                    );

                if (mayProceed) {

                    this.clearWait(
                        actor
                    );

                    return true;

                }

                this.waitingFor.set(
                    actor,
                    currentSidestep.other
                );

                return false;

            }

        }

        /*
         * Só atualiza o sidestep depois de confirmar
         * que ele não está ocorrendo na zona de um nó.
         */
        const activeSidestepDecision =
            this.updateSidestep(
                actor,
                delta
            );

        if (
            activeSidestepDecision !== null
        ) {

            return activeSidestepDecision;

        }

        let blocker =
            null;

        let closestClearance =
            Infinity;

        for (
            const other of
            this.owner.contexts.keys()
        ) {

            if (
                other === actor ||
                !other.isActive()
            ) {

                continue;

            }

            const verticalSeparation =
                Math.abs(
                    actor.object3D.position.y -
                    other.object3D.position.y
                );

            const collisionHeight =
                Math.min(
                    actor.collisionHeight ??
                    1.2,

                    other.collisionHeight ??
                    1.2
                );

            if (
                verticalSeparation >
                collisionHeight
            ) {

                continue;

            }

            const currentDistance =
                actor.object3D.position
                    .distanceTo(
                        other.object3D.position
                    );

            if (
                currentDistance >
                this.detectionRadius
            ) {

                continue;

            }

            /*
             * IMPORTANTE:
             *
             * O conflito de nó é verificado antes
             * de useDifferentLanes().
             *
             * Duas lanes diferentes podem convergir
             * para o mesmo nó.
             */
            const nodeConflictId =
                this.getNodeConflictId(
                    actor,
                    other
                );

            if (nodeConflictId) {

                /*
                 * Garante que nenhuma manobra lateral
                 * permaneça ativa quando o par está
                 * negociando passagem em um nó.
                 */
                this.cancelPairSidestepsForNode(
                    actor,
                    other,
                    nodeConflictId
                );

                const mayProceed =
                    this.resolveNodeConflict(
                        actor,
                        other,
                        nodeConflictId
                    );

                if (
                    !mayProceed &&
                    currentDistance <
                    closestClearance
                ) {

                    blocker =
                        other;

                    closestClearance =
                        currentDistance;

                }

                /*
                 * Este continue é essencial.
                 *
                 * Mesmo quando actor pode prosseguir,
                 * o par não deve chegar ao fluxo de
                 * sidestep neste frame.
                 */
                continue;

            }

            /*
             * Fora da zona de um nó, atores em lanes
             * realmente diferentes não representam
             * um conflito.
             */
            if (
                this.useDifferentLanes(
                    actor,
                    other
                )
            ) {

                continue;

            }

            const requiredClearance =
                (
                    actor.collisionRadius ??
                    0.36
                ) +
                (
                    other.collisionRadius ??
                    0.36
                ) +
                this.safetyPadding;

            const otherTarget =
                other.navigation
                    .getCurrentWaypoint()
                    ?.position;

            this.getIntendedVelocity(
                other,
                otherTarget,
                this.otherVelocity
            );

            const predictedClearance =
                currentDistance <
                    requiredClearance

                    ? currentDistance

                    : this.getPredictedClearance(
                        actor,
                        other
                    );

            if (
                predictedClearance >=
                requiredClearance
            ) {

                continue;

            }

            const shouldYield =
                this.shouldYield(
                    actor,
                    other
                );

            /*
             * Durante o cooldown, o mesmo par não
             * inicia imediatamente outro sidestep.
             *
             * O ator que deve ceder espera.
             * O ator prioritário pode continuar.
             */
            if (
                this.isPairCoolingDown(
                    actor,
                    other
                )
            ) {

                if (
                    shouldYield &&
                    predictedClearance <
                    closestClearance
                ) {

                    blocker =
                        other;

                    closestClearance =
                        predictedClearance;

                }

                continue;

            }

            /*
             * Fora dos nós, ambos podem participar
             * da micro-manobra.
             *
             * O Player desloca menos. O ator que
             * cede desloca um pouco mais.
             */
            const sidestepTarget =
                this.beginSidestep(
                    actor,
                    other,
                    target,
                    shouldYield
                );

            if (sidestepTarget) {

                this.clearWait(
                    actor
                );

                return {
                    allowed: true,

                    target:
                        sidestepTarget,

                    temporary: true
                };

            }

            /*
             * Se o ator prioritário não encontrou
             * espaço lateral, ele ainda pode avançar.
             *
             * O ator que deve ceder torna-se o ator
             * bloqueado.
             */
            if (!shouldYield) {

                continue;

            }

            if (
                predictedClearance <
                closestClearance
            ) {

                blocker =
                    other;

                closestClearance =
                    predictedClearance;

            }

        }

        if (!blocker) {

            this.clearWait(
                actor
            );

            return true;

        }

        const previousBlocker =
            this.waitingFor.get(
                actor
            );

        this.waitingFor.set(
            actor,
            blocker
        );

        if (
            previousBlocker !== blocker
        ) {

            console.log(
                `[CollisionFailsafe] ` +
                `${actor.name} waits for ` +
                `${blocker.name}; predicted ` +
                `clearance ` +
                `${closestClearance.toFixed(2)}.`
            );

        }

        return false;

    }

    isWaitingAtLaneEndpoint(actor) {

        const traffic = this.owner.traffic;
        const graph = this.owner.graph;
        const connection = actor.navigation.getTraversalState().currentConnection;

        if (!traffic || !connection) return false;
        if (!traffic.isQueuedAtNode(connection.toId, actor)) return false;
        if (graph.isNodeAvailable(connection.toId, actor) &&
            traffic.isFirstAtNode(connection.toId, actor)) return false;

        const laneIndex = graph.getConnectionLaneIndex(
            connection.fromId,
            connection.toId,
            actor
        );
        if (laneIndex === null) return false;

        const endpoint = graph.getConnectionLaneNodePosition(
            connection.toId,
            connection.fromId,
            connection.toId,
            laneIndex
        );
        const endpointDistance = actor.object3D.position.distanceTo(endpoint);
        const stoppingDistance = Math.max(
            0.85,
            (actor.collisionRadius ?? 0.42) * 2.2
        );

        return endpointDistance <= stoppingDistance;

    }

    updateSidestep(
        actor,
        delta
    ) {

        const sidestep =
            this.sidesteps.get(
                actor
            );

        if (!sidestep) {

            return null;

        }

        sidestep.elapsed +=
            Math.max(
                delta,
                0
            );

        const distance =
            actor.object3D.position
                .distanceTo(
                    sidestep.target
                );

        if (
            distance <=
            this.sidestepArrivalDistance
        ) {

            this.finishSidestep(
                actor,
                sidestep
            );

            /*
             * Retorna null para permitir que o
             * ator retome o waypoint verdadeiro
             * ainda neste frame.
             */
            return null;

        }

        if (
            sidestep.elapsed >=
            this.sidestepTimeout
        ) {

            this.abortSidestep(
                actor,
                sidestep
            );

            /*
             * Neste frame o ator para. No frame
             * seguinte, o cooldown impede a
             * recriação imediata da manobra.
             */
            return false;

        }

        return {
            allowed: true,

            target:
                sidestep.target,

            temporary: true
        };

    }

    finishSidestep(
        actor,
        sidestep
    ) {

        this.sidesteps.delete(
            actor
        );

        this.setPairCooldown(
            actor,
            sidestep.other
        );

        console.log(
            `[CollisionFailsafe] ` +
            `${actor.name} completed the ` +
            `sidestep around ` +
            `${sidestep.other.name}.`
        );

    }

    abortSidestep(
        actor,
        sidestep
    ) {

        this.sidesteps.delete(
            actor
        );

        this.setPairCooldown(
            actor,
            sidestep.other
        );

        console.warn(
            `[CollisionFailsafe] ` +
            `${actor.name} aborted the ` +
            `sidestep around ` +
            `${sidestep.other.name} after ` +
            `${sidestep.elapsed.toFixed(2)}s.`
        );

        this.recordSidestepFailure(
            actor
        );

    }

    cancelPairSidestepsForNode(
        first,
        second,
        nodeId
    ) {

        const firstSidestep =
            this.sidesteps.get(
                first
            );

        if (
            firstSidestep?.other ===
            second
        ) {

            this.sidesteps.delete(
                first
            );

        }

        const secondSidestep =
            this.sidesteps.get(
                second
            );

        if (
            secondSidestep?.other ===
            first
        ) {

            this.sidesteps.delete(
                second
            );

        }

        this.rememberNodeConflict(
            first,
            second,
            nodeId
        );

        console.log(
            `[CollisionFailsafe] ` +
            `sidestep between ` +
            `${first.name} and ` +
            `${second.name} cancelled at ` +
            `node ${nodeId}.`
        );

    }

    setPairCooldown(
        first,
        second
    ) {

        if (
            !first ||
            !second
        ) {

            return;

        }

        const expiresAt =
            Date.now() +
            this.sidestepCooldown *
            1000;

        this.setCooldownEntry(
            first,
            second,
            expiresAt
        );

        this.setCooldownEntry(
            second,
            first,
            expiresAt
        );

    }

    setCooldownEntry(
        actor,
        other,
        expiresAt
    ) {

        let entries =
            this.pairCooldowns.get(
                actor
            );

        if (!entries) {

            entries =
                new Map();

            this.pairCooldowns.set(
                actor,
                entries
            );

        }

        entries.set(
            other,
            expiresAt
        );

    }

    isPairCoolingDown(
        actor,
        other
    ) {

        const entries =
            this.pairCooldowns.get(
                actor
            );

        if (!entries) {

            return false;

        }

        const expiresAt =
            entries.get(
                other
            );

        if (!expiresAt) {

            return false;

        }

        if (
            Date.now() <
            expiresAt
        ) {

            return true;

        }

        entries.delete(
            other
        );

        if (
            entries.size === 0
        ) {

            this.pairCooldowns.delete(
                actor
            );

        }

        return false;

    }

    getNodeConflictId(
        actor,
        other
    ) {

        /*
         * Primeiro tenta conservar uma
         * classificação feita recentemente.
         *
         * Isso evita:
         *
         * nó em um frame
         * conexão no próximo
         * sidestep no seguinte
         */
        const rememberedNodeId =
            this.getRememberedNodeConflictId(
                actor,
                other
            );

        if (rememberedNodeId) {

            return rememberedNodeId;

        }

        /*
         * A posição física possui precedência
         * sobre currentNodeId e currentConnection.
         *
         * Um ator pode estar visualmente sobre o
         * nó mesmo quando a navegação já alterou
         * seu estado lógico.
         */
        const actorSpatialNodeId =
            this.getNearestConflictNodeId(
                actor
            );

        const otherSpatialNodeId =
            this.getNearestConflictNodeId(
                other
            );

        if (
            actorSpatialNodeId &&
            actorSpatialNodeId ===
            otherSpatialNodeId
        ) {

            this.rememberNodeConflict(
                actor,
                other,
                actorSpatialNodeId
            );

            return actorSpatialNodeId;

        }

        /*
         * Fallback para os dados da travessia.
         * Ainda exige que ambos estejam
         * fisicamente próximos do mesmo nó.
         */
        const actorNodeIds =
            this.getContestedNodeIds(
                actor
            );

        const otherNodeIds =
            this.getContestedNodeIds(
                other
            );

        for (
            const nodeId of
            actorNodeIds
        ) {

            if (
                !otherNodeIds.has(
                    nodeId
                )
            ) {

                continue;

            }

            if (
                !this.isNearNode(
                    actor,
                    nodeId
                ) ||
                !this.isNearNode(
                    other,
                    nodeId
                )
            ) {

                continue;

            }

            this.rememberNodeConflict(
                actor,
                other,
                nodeId
            );

            return nodeId;

        }

        return null;

    }

    getNearestConflictNodeId(
        actor
    ) {

        const graph =
            this.owner.graph;

        const maximumDistanceSquared =
            this.nodeConflictRadius ** 2;

        let nearestNodeId =
            null;

        let nearestDistanceSquared =
            maximumDistanceSquared;

        for (
            const [
                nodeId,
                node
            ] of graph.getNodeEntries()
        ) {

            const distanceSquared =
                graph.getPlanarDistanceSquared(
                    actor.object3D.position,
                    node.position
                );

            if (
                distanceSquared >
                nearestDistanceSquared
            ) {

                continue;

            }

            nearestDistanceSquared =
                distanceSquared;

            nearestNodeId =
                nodeId;

        }

        return nearestNodeId;

    }

    rememberNodeConflict(
        first,
        second,
        nodeId
    ) {

        const expiresAt =
            Date.now() +
            this.nodeConflictHoldDuration *
            1000;

        this.setNodeConflictMemoryEntry(
            first,
            second,
            nodeId,
            expiresAt
        );

        this.setNodeConflictMemoryEntry(
            second,
            first,
            nodeId,
            expiresAt
        );

    }

    setNodeConflictMemoryEntry(
        actor,
        other,
        nodeId,
        expiresAt
    ) {

        let entries =
            this.nodeConflictMemory.get(
                actor
            );

        if (!entries) {

            entries =
                new Map();

            this.nodeConflictMemory.set(
                actor,
                entries
            );

        }

        entries.set(
            other,
            {
                nodeId,
                expiresAt
            }
        );

    }

    getRememberedNodeConflictId(
        actor,
        other
    ) {

        const entries =
            this.nodeConflictMemory.get(
                actor
            );

        const record =
            entries?.get(
                other
            );

        if (!record) {

            return null;

        }

        if (
            Date.now() >
            record.expiresAt
        ) {

            entries.delete(
                other
            );

            if (
                entries.size === 0
            ) {

                this.nodeConflictMemory.delete(
                    actor
                );

            }

            return null;

        }

        /*
         * Durante a memória curta usamos uma
         * margem adicional. Assim, cruzar
         * levemente a borda do raio não muda
         * imediatamente o encontro para
         * sidestep.
         */
        const releaseRadius =
            this.nodeConflictRadius +
            this.nodeConflictReleaseMargin;

        if (
            !this.isNearNode(
                actor,
                record.nodeId,
                releaseRadius
            ) ||
            !this.isNearNode(
                other,
                record.nodeId,
                releaseRadius
            )
        ) {

            entries.delete(
                other
            );

            return null;

        }

        return record.nodeId;

    }

    getContestedNodeIds(
        actor
    ) {

        const ids =
            new Set();

        const traversal =
            actor.navigation
                .getTraversalState();

        if (
            traversal.currentNodeId
        ) {

            ids.add(
                traversal.currentNodeId
            );

        }

        /*
         * Para um ator numa conexão, o nó
         * disputado é o endpoint ao qual ele
         * está chegando, não aquele que já
         * deixou.
         */
        if (
            traversal.currentConnection
                ?.toId
        ) {

            ids.add(
                traversal
                    .currentConnection
                    .toId
            );

        }

        const waypoint =
            actor.navigation
                .getCurrentWaypoint();

        if (
            waypoint?.id &&
            this.owner.graph.hasNode(
                waypoint.id
            )
        ) {

            ids.add(
                waypoint.id
            );

        }

        return ids;

    }

    isNearNode(
        actor,
        nodeId,
        radius =
            this.nodeConflictRadius
    ) {

        const node =
            this.owner.graph.getNode(
                nodeId
            );

        if (!node) {

            return false;

        }

        return this.owner.graph
            .getPlanarDistanceSquared(
                actor.object3D.position,
                node.position
            ) <=
            radius ** 2;

    }

    resolveNodeConflict(
        actor,
        other,
        nodeId
    ) {

        const graph =
            this.owner.graph;

        const traffic =
            this.owner.traffic;

        const actorTraversal =
            actor.navigation
                .getTraversalState();

        const otherTraversal =
            other.navigation
                .getTraversalState();

        const actorOccupiesNode =
            actorTraversal.currentNodeId ===
            nodeId;

        const otherOccupiesNode =
            otherTraversal.currentNodeId ===
            nodeId;

        /*
         * Quem já está no nó precisa poder sair.
         * Dar prioridade absoluta ao Player aqui
         * poderia manter um NPC preso no centro
         * enquanto o Player tenta entrar.
         */
        if (
            actorOccupiesNode &&
            !otherOccupiesNode
        ) {

            return true;

        }

        if (
            otherOccupiesNode &&
            !actorOccupiesNode
        ) {

            return false;

        }

        /*
         * Se ambos estão chegando, a fila de
         * arrival possui autoridade sobre a
         * colisão social.
         */
        const actorQueued =
            traffic?.isQueuedAtNode(
                nodeId,
                actor
            ) ?? false;

        const otherQueued =
            traffic?.isQueuedAtNode(
                nodeId,
                other
            ) ?? false;

        if (
            actorQueued &&
            otherQueued
        ) {

            const actorIsFirst =
                traffic.isFirstAtNode(
                    nodeId,
                    actor
                );

            const otherIsFirst =
                traffic.isFirstAtNode(
                    nodeId,
                    other
                );

            if (
                actorIsFirst !==
                otherIsFirst
            ) {

                return actorIsFirst;

            }

        }

        /*
         * Uma reserva ou ocupação válida do
         * outro ator impede a entrada.
         */
        if (
            !graph.isNodeAvailable(
                nodeId,
                actor
            )
        ) {

            return false;

        }

        /*
         * Empates que não foram resolvidos pela
         * ocupação nem pela fila usam prioridade
         * e, por último, a ordem estável dos
         * atores.
         */
        return !this.shouldYield(
            actor,
            other
        );

    }

    recordSidestepFailure(
        actor
    ) {

        const now =
            Date.now() /
            1000;

        const windowStart =
            now -
            this.sidestepFailureWindow;

        const failures =
            (
                this.sidestepFailures.get(
                    actor
                ) ??
                []
            )
                .filter(
                    timestamp =>
                        timestamp >=
                        windowStart
                );

        failures.push(
            now
        );

        if (
            failures.length <
            this.maxSidestepFailures
        ) {

            this.sidestepFailures.set(
                actor,
                failures
            );

            return;

        }

        this.sidestepFailures.delete(
            actor
        );

        const context =
            this.owner.contexts.get(
                actor
            );

        if (!context) {

            return;

        }

        const hasPreservedIntent =
            Boolean(
                context.pendingInteraction ||
                context.pendingPosition
            );

        if (!hasPreservedIntent) {

            return;

        }

        console.warn(
            `[CollisionFailsafe] ` +
            `${actor.name} failed ` +
            `${failures.length} sidesteps; ` +
            `rebuilding the preserved route.`
        );

        this.owner
            .restartIntentFromNearestAccess(
                context
            );

    }

    getIntendedVelocity(actor, target, result) {

        result.set(0, 0, 0);

        if (!target || actor.navigation.isPaused()) return result;

        result.subVectors(target, actor.object3D.position).setY(0);

        if (result.lengthSq() <= 0.0001) return result.set(0, 0, 0);

        return result.normalize().multiplyScalar(actor.locomotion.speed);

    }

    useDifferentLanes(actor, other) {

        const first = actor.navigation.getTraversalState().currentConnection;
        const second = other.navigation.getTraversalState().currentConnection;

        if (!first || !second) return false;

        const sameConnection =
            (first.fromId === second.fromId && first.toId === second.toId) ||
            (first.fromId === second.toId && first.toId === second.fromId);

        if (!sameConnection) return false;

        const firstLane = this.owner.graph.getConnectionLaneIndex(
            first.fromId,
            first.toId,
            actor
        );
        const secondLane = this.owner.graph.getConnectionLaneIndex(
            second.fromId,
            second.toId,
            other
        );

        return firstLane !== null &&
            secondLane !== null &&
            firstLane !== secondLane;

    }

    getPredictedClearance(actor, other) {

        this.relativePosition.subVectors(
            other.object3D.position,
            actor.object3D.position
        ).setY(0);
        this.relativeVelocity.subVectors(
            this.otherVelocity,
            this.velocity
        ).setY(0);

        const speedSquared = this.relativeVelocity.lengthSq();
        const closestTime = speedSquared > 0.0001
            ? THREE.MathUtils.clamp(
                -this.relativePosition.dot(this.relativeVelocity) /
                speedSquared,
                0,
                this.predictionTime
            )
            : 0;

        return this.relativePosition.addScaledVector(
            this.relativeVelocity,
            closestTime
        ).length();

    }

    shouldYield(actor, other) {

        const actorPriority =
            this.getCommitmentPriority(
                actor
            );

        const otherPriority =
            this.getCommitmentPriority(
                other
            );

        if (
            actorPriority !==
            otherPriority
        ) {

            return actorPriority <
                otherPriority;

        }

        if (
            this.waitingFor.get(other) ===
            actor
        ) {

            return false;

        }

        const actorMoving = this.velocity.lengthSq() > 0.0001;
        const otherMoving = this.otherVelocity.lengthSq() > 0.0001;

        if (!actorMoving) return false;
        if (!otherMoving) return true;

        const actors = [...this.owner.contexts.keys()];
        return actors.indexOf(actor) > actors.indexOf(other);

    }

    getCommitmentPriority(actor) {

        const context = this.owner.contexts.get(actor);

        const actorPriority =
            actor.navigationPriority ??
            0;

        if (!context) {

            return actorPriority;

        }

        if (context.activeInteraction) {

            return actorPriority + 3;

        }

        const interaction = context.pendingInteraction?.point;
        const approach = interaction?.via;
        const reserved = Boolean(
            interaction?.reservations.has(actor) ||
            interaction?.occupants.has(actor) ||
            approach?.reservations.has(actor) ||
            approach?.occupants.has(actor)
        );

        if (reserved) {

            return actorPriority + 2;

        }

        if (context.interactionPoint) {

            return actorPriority + 1;

        }

        return actorPriority;

    }

    beginSidestep(
        actor,
        other,
        target,
        shouldYield
    ) {

        if (!target) {

            return null;

        }

        const nodeConflictId =
            this.getNodeConflictId(
                actor,
                other
            );

        if (nodeConflictId) {

            this.rememberNodeConflict(
                actor,
                other,
                nodeConflictId
            );

            return null;

        }

        const relative =
            other.object3D.position
                .clone()
                .sub(
                    actor.object3D.position
                )
                .setY(0);

        const forward =
            this.velocity
                .clone()
                .setY(0);

        /*
         * Um ator parado pode usar a direção
         * relativa ao outro como referência.
         */
        if (
            forward.lengthSq() <
            0.0001
        ) {

            forward.copy(
                relative
            );

        }

        if (
            forward.lengthSq() <
            0.0001
        ) {

            return null;

        }

        forward.normalize();

        /*
         * Para um Object3D cujo forward é +Z:
         *
         * forward (0, 0, 1)
         * right   (1, 0, 0)
         */
        const right =
            new THREE.Vector3(
                forward.z,
                0,
                -forward.x
            );

        const sidestepDistance =
            this.getSidestepDistance(
                actor,
                shouldYield
            );

        /*
         * Há um avanço muito pequeno. A manobra
         * não deve parecer um passo completamente
         * perpendicular ao caminho.
         */
        const forwardDistance =
            actor.locomotion.speed *
            (
                shouldYield
                    ? 0.05
                    : 0.08
            );

        const origin =
            actor.object3D.position;

        const rightCandidate =
            origin.clone()
                .addScaledVector(
                    right,
                    sidestepDistance
                )
                .addScaledVector(
                    forward,
                    forwardDistance
                );

        const leftCandidate =
            origin.clone()
                .addScaledVector(
                    right,
                    -sidestepDistance
                )
                .addScaledVector(
                    forward,
                    forwardDistance
                );

        const rightClearance =
            this.owner.physics
                .getClearanceForPosition(
                    actor,
                    rightCandidate
                );

        const leftClearance =
            this.owner.physics
                .getClearanceForPosition(
                    actor,
                    leftCandidate
                );

        /*
         * Com espaços equivalentes, mantém-se
         * à própria direita. Para dois atores
         * em sentidos opostos, a direita de cada
         * um corresponde a lados mundiais
         * diferentes.
         */
        const rightIsUsable =
            rightClearance >= -0.12;

        const leftIsUsable =
            leftClearance >= -0.12;

        if (
            !rightIsUsable &&
            !leftIsUsable
        ) {

            return null;

        }

        const useRight =
            rightIsUsable &&
            (
                !leftIsUsable ||
                rightClearance >=
                leftClearance - 0.08
            );

        const candidate =
            useRight
                ? rightCandidate
                : leftCandidate;

        this.sidesteps.set(
            actor,
            {
                other,

                target:
                    candidate.clone(),

                side:
                    useRight
                        ? "right"
                        : "left",

                elapsed: 0
            }
        );

        console.log(
            `[CollisionFailsafe] ` +
            `${actor.name} begins a short ` +
            `${useRight ? "right" : "left"} ` +
            `sidestep around ${other.name}.`
        );

        return candidate;

    }

    getSidestepDistance(
        actor,
        shouldYield
    ) {

        if (
            actor.navigationPriority >= 100
        ) {

            return this
                .playerSidestepDistance;

        }

        return shouldYield

            ? this
                .yieldingSidestepDistance

            : this
                .prioritySidestepDistance;

    }

    clearWait(actor) {

        const blocker = this.waitingFor.get(actor);

        if (!blocker) return;

        this.waitingFor.delete(actor);
        console.log(
            `[CollisionFailsafe] ${actor.name} may continue; ` +
            `${blocker.name} is clear.`
        );

    }

    unregister(
        actor
    ) {

        this.cancel(
            actor
        );

        for (
            const [
                waitingActor,
                blocker
            ] of this.waitingFor
        ) {

            if (
                blocker === actor
            ) {

                this.clearWait(
                    waitingActor
                );

            }

        }

    }

    cancel(
        actor
    ) {

        this.clearWait(
            actor
        );

        this.sidesteps.delete(
            actor
        );

        this.sidestepFailures.delete(
            actor
        );

        this.pairCooldowns.delete(
            actor
        );

        this.nodeConflictMemory.delete(
            actor
        );

        /*
         * Remove manobras que apontavam para o
         * ator cancelado ou removido.
         */
        for (
            const [
                movingActor,
                sidestep
            ] of this.sidesteps
        ) {

            if (
                sidestep.other === actor
            ) {

                this.sidesteps.delete(
                    movingActor
                );

            }

        }

        /*
         * Remove referências ao ator nos mapas
         * de cooldown dos demais.
         */
        for (
            const [
                other,
                entries
            ] of this.pairCooldowns
        ) {

            entries.delete(
                actor
            );

            if (
                entries.size === 0
            ) {

                this.pairCooldowns.delete(
                    other
                );

            }

        }

        for (
            const [
                other,
                entries
            ] of this.nodeConflictMemory
        ) {

            entries.delete(
                actor
            );

            if (
                entries.size === 0
            ) {

                this.nodeConflictMemory.delete(
                    other
                );

            }

        }

    }

}
