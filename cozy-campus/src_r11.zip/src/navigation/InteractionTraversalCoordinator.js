import { EntityState } from "../core/EntityState";
import { AnimationPresets } from "../core/AnimationPresets";
import { Tween } from "../core/Tween";

// Coordena a transação física de entrada/saída de InteractionPoints. Enquanto
// uma saída está committed, a ocupação só é liberada depois do onComplete.
export class InteractionTraversalCoordinator {

    constructor(navigation) {

        this.navigation = navigation;
        this.graph = navigation.graph;
        this.connector = navigation.connector;
        this.interactionTraffic = navigation.interactionTraffic;
        this.traffic = navigation.traffic;
        this.interactions = navigation.interactions;

    }

    beginInteractionExit(context, command) {

        if (context.interaction.leaving) {

            // A newer Player command replaces the destination, but never cuts
            // short the stand-up/release animation already in progress.
            context.intent.deferredCommand = command;
            return;

        }

        if (context.interaction.exitCommitted) {

            // The actor has already stood up or left its action pose. A new
            // target replaces only what happens after the exit; replaying the
            // exit animation would teleport it back toward the old action.
            context.intent.deferredCommand = command;

            if (!context.actor.navigation.hasPath()) {

                this.navigation.executeDeferredCommand(context, {
                    skipInteractionExit: true
                });

            }
            return;

        }

        const interaction = context.interaction.active;
        const approachPoint = interaction.point.via ?? interaction.point;
        const exitWaypoints = this.connector.createExitWaypoints(
            interaction.point,
            command.originId,
            { nextNodeId: command.nextNodeId ?? null }
        );
        const connectionEntry = exitWaypoints.find(
            waypoint => waypoint.connectionEntry
        )?.connectionEntry ?? null;

        context.intent.deferredCommand = command;
        context.actor.pause();

        // Reserve the real exit before playing the visual transition. Without
        // this preflight, the actor visibly stood up and only then discovered
        // that its lane was busy, appearing frozen beside the interaction.
        if (!this.traffic.preflightInteractionExit(
            context.actor,
            connectionEntry
        )) {

            context.wait.retryElapsed = 0;
            return;

        }

        context.interaction.exitCommitted = true;
        context.interaction.leaving = true;
        context.interaction.exitElapsed = 0;

        interaction.target?.prepareInteractionExit(
            context.actor,
            interaction.point,
            approachPoint,
            () => {

                if (!context.interaction.leaving) return;

                context.interaction.leaving = false;
                context.interaction.exitElapsed = 0;
                this.navigation.executeDeferredCommand(context, {
                    skipInteractionExit: true
                });

            }
        );

    }

    completeInteractionExit(context) {

        this.leaveInteractionPoint(context);
        this.releaseInteractionExitPoint(context);
        context.interaction.exitCommitted = false;

    }

    finishActiveInteraction(context) {

        const interaction = context.interaction.active;

        if (!interaction) return;

        interaction.target?.endInteraction(
            context.actor,
            interaction.point
        );
        context.interaction.active = null;

    }

    leaveInteractionPoint(context) {

        if (!context.traversal.interactionPoint) return;

        if (context.interaction.active?.point === context.traversal.interactionPoint) {

            this.finishActiveInteraction(context);

        }

        this.interactionTraffic.releasePoint(
            context.traversal.interactionPoint,
            context.actor
        );

        context.traversal.interactionPoint = null;

    }

    releaseInteractionExitPoint(context) {

        if (!context.traversal.interactionExitPoint) return;

        this.interactionTraffic.releasePoint(
            context.traversal.interactionExitPoint,
            context.actor
        );

        context.traversal.interactionExitPoint = null;

    }

    completeInteractionAtCurrentPosition(context, point, onArrive) {

        const { actor } = context;

        this.traffic.cancel(actor);
        this.navigation.trafficState.releaseReservations(actor);
        this.interactionTraffic.releaseReservations(actor);
        this.navigation.routeGeometry.clearActiveLaneCurve(actor);
        actor.navigation.clearRoute();
        actor.locomotion.resetCurve();

        context.intent.position = null;
        context.intent.destinationId = null;
        context.intent.interaction = { point, onArrive };
        context.intent.deferredCommand = null;
        context.traversal.laneCurve = false;
        context.traversal.interactionCurve = false;
        context.recovery.elapsed = 0;
        context.recovery.position.copy(actor.object3D.position);

        this.interactions.handleWaypoint(context, {
            id: null,
            position: point.getWorldPosition(),
            interactionPoint: point
        });

        this.navigation.refresh();
        return true;

    }

}
